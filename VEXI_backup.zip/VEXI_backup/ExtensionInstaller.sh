#! /bin/bash

echo "(THE STORED EXTENSIONS WILL START TO INSTALL)"

code --install-extension bierner.markdown-preview-github-styles
code --install-extension icrawl.discord-vscode
code --install-extension ms-python.python
code --install-extension ms-python.vscode-pylance
code --install-extension ms-toolsai.jupyter
code --install-extension ms-toolsai.jupyter-keymap
code --install-extension ms-toolsai.jupyter-renderers
code --install-extension PKief.material-icon-theme
code --install-extension redhat.fabric8-analytics
code --install-extension redhat.java
code --install-extension ritwickdey.LiveServer
code --install-extension usernamehw.errorlens
code --install-extension VisualStudioExptTeam.vscodeintellicode
code --install-extension vscjava.vscode-java-debug
code --install-extension vscjava.vscode-java-dependency
code --install-extension vscjava.vscode-java-pack
code --install-extension vscjava.vscode-java-test
code --install-extension vscjava.vscode-maven
code --install-extension zhuangtongfa.material-theme

echo "(TASK COMPLETE!)"
# backup created on:  Mon Mar 28 09:03:01 PM IST 2022
